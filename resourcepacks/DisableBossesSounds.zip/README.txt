This resource pack removes the Wither spawn and death sounds, and the Ender Dragon death sounds.
Very useful on multiplayer servers. This has been tested with 1.7.10 and 1.10.2 versions. Ignore the incompatible message, it'll work anyway without causing any issue.

- How to install -
Place this zip file on the resourcepacks folder inside your Minecraft installation (either on %appdata% for Minecraft Launcher or FTBLauncher, or your Instances folder on ATLauncher). You don't have to extract this zip file.

